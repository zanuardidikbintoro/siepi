<?php
include 'accesscontrol.php'; 
?>
 <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="align-items-center">
                                    <div>
                                        <h4 class="card-title">Tentukan Lokasi IKM</h4>
                                        <h5 class="card-subtitle">Pilih Area pada Map di Bawah ini</h5>
										
										<div class="resp-container">
    <iframe class="resp-iframe" src="../user-map.php" gesture="media"  allow="encrypted-media" allowfullscreen></iframe>
</div>
                                    </div>
                                </div>
								</div>
								</div>
								</div>
								</div>