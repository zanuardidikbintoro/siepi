<?php
include 'accesscontrol.php'; 
?>
 <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="align-items-center">
                                    <div>
                                        <h4 class="card-title">Welcome Admin !</h4>
                                        <h5 class="card-subtitle">hi, good morning</h5>
										Selamat datang di menu admin Si-EPI, gunakan menu di sebelah kiri untuk manajemen konten Si-EPI
										<p>
										<a class="btn btn-success" href="../index.php" target="_blank">Cek Site</a>
										</div>
                                </div>
								</div>
								</div>
								</div>
								</div>