<?php
include 'accesscontrol.php'; 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
Konsultasi dengan narasumber
</body>
</html>