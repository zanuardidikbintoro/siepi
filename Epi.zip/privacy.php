<table class="">
  <tr>
    <td align="center"><h1></h1>
   <br />
    </td> <!-- 
  </tr>
   <tr>
    <td align="center"><h1></h1>
  
   <center><a class="btn btn-info btn-sm" href="http://edumob.octoiner.com/index.php?kat=<?=$_GET['kat'];?>">Back</a></center> <br />
    </td>
  </tr>-->
  
  
  <tr>
    <td class="text-justify"><h1>Privacy Policy</h1>
      
      <p>Admin <strong>ikmpurworejo.com</strong> menyadari bahwa privasi Anda sangat penting. Kebijakan Privasi ini berlaku untuk semua informasi yang ditawarkan di website ini. Namun ada saatnya kami membutuhkan informasi tertentu dari Anda untuk memungkinkan kami melayani Anda lebih baik.</p>
      <p><strong>ikmpurworejo</strong>.com adalah pemilik tunggal data yang Anda kirimkan melalui halaman kontak kami. Kami tidak membagikan, menjual, atau menyewakan semua informasi Anda tersebut kepada pihak lain.</p>
      <h3>Keamanan</h3>
      <p><strong>ikmpurworejo.com</strong> memahami kebutuhan kerahasiaan informasi pribadi Anda. Kami berusaha untuk benar-benar melindungi informasi pribadi Anda dari kehilangan, manipulasi, pemalsuan atau akses yang tidak sah untuk tujuan yang tidak bertanggung jawab.</p>
      <h3>Link Eksternal</h3>
      <p>Website ini dirancang untuk memungkinkan me-link ke situs-situs lain. Kami tidak bertanggung jawab atas kebijakan privasi atau kekurangan dari situs-situs lain tersebut. Kami menyarankan konsumen untuk membaca dengan seksama pernyataan privasi dari situs web lain.</p>
      <div></div>
      <div>
      
      </div>
      <h3>Cookies</h3>
      <p><strong>ikmpurworejo.com</strong> menggunakan cookies untuk menyimpan informasi berupa preferensi dari visitor, merekam informasi spesifik visitor dan dari halaman mana yang mereka kunjungi. Menyesuaikan halaman web berdasarkan tipe browser atau informasi lain yang dikirim melalui browser visitor.</p>
      <p>Kami juga bekerjasama dengan pihak ketiga penyedia iklan <em>(third party ad servers)</em>, yang biasanya menggunakan cookies  atau informasi dari browser Anda untuk mengukur efektivitas iklan mereka, termasuk untuk menyediakan iklan yang relevan bagi Anda.</p>
      <h3>Perubahan Pernyataan</h3>
      <p><strong>ikmpurworejo.com</strong> berhak untuk mengubah kebijakan privasi tanpa pemberitahuan. Kami merekomendasikan pengunjung untuk secara berkala membaca kembali pernyataan kebijakan privasi untuk melihat perubahan terkini.</p></td>
  </tr>
  <tr>
      
    <td  class="text-justify">
		   Terimakasih telah berkunjung ke website kami <a href="http://ikmpurworejo.com" title="http://ikmpurworejo.com" target="_blank">http://ikmpurworejo.com</a> </p>
	  </td>
  </tr>
</table>
